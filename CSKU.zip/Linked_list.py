""" the linked list"""
import random
from final_project import *

class Node():
    def __init__(self,data):
        self.data=data
        self.next=None
# the above example just make the node with no link or reference to the next node (just node) with data and next
class Linked_list:
    def __init__(self,capacity):
        self.capacity_linked_list =capacity
        self.length_linked_list = None
        self.head_linked_list = None
        self.length = 0
        self.head = None

    def __repr__(self):
        str_ = " "
        temp = self.head
        while temp.next:
            str_ += str(temp.data) + "->"
            temp = temp.next
        else:
            str_ += str(temp.data)
        return str_

    def is_empty_ll(self):
        return self.length ==0

# made the linked list in here based on the capacity of the linked list in here:
