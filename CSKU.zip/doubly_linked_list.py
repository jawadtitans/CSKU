# the above example just make the node with no link or reference to the next node (just node) with data and next
class Node:
    def __init__(self,data):
        self.next = None
        self.prev=None
        self.data = data
class doubly_Linke_list:
    def __init__(self,capacity):
        self.length = 0
        self.capacity=capacity
        self.head=None
        self.front=None
    def push(self,data): # at the back of linked lst:
        if self.length==self.capacity:
            print(" the capacity of linked list is full")
        elif self.head is None: # if our linke list is empty: or does not have anythig in here: so!!!!
            new_node=Node(data)
            self.head=new_node
            self.front=self.head
            self.length+=1
        else:# adding a node at the begin of the linked list.
            new_node=Node(data) # we made the new node in here.'
            new_node.next=self.head
            self.head.prev=new_node
            self.head=new_node
            self.length+=1
    def append(self,data):
        if self.length==self.capacity:
            print(" the capacity of linked list is full")
        else:
            new_node=Node(data)
            temp=self.head # we need to create a reference to my ll to can go over the list:
            while temp.next: # it means while we have to next in our linked-list so we just need to define it in the.
                temp=temp.next
            else:
                temp.next=new_node #it means it is the last element of the ll and it we want to add a new node at the end of the linked list .
                new_node.prev = temp
                self.length+=1
    def __len__(self):
        length=0
        temp=self.head
        while temp.next:
            temp=temp.next
        else:
            length+=1
        return length + 1
    def is_empty_ll(self):
        return self.length==0

    def insert(self,index,data):
          if self.length ==self.capacity:
              print("the capcity of linked list is full")
          else:
              if index<=0:
                  self.push(data)
              elif index>=self.length-1:
                  self.append(data)
              else:
                  temp=pre=self.head
                  while index: # it means until the index is not arrive to my index that i have been saved in here it should go forward like this one.
                      pre=temp
                      temp=temp.next
                      index-=1
                  else:
                      new_node=Node(data)
                      new_node.next=temp
                      temp.prev=new_node
                      pre.next=new_node
                      new_node.prev=pre
                      self.length+=1
##########################################
    def pop(self,index=-1):
        if index >self.capacity:
            print("out of range!!!")
        elif self.length==0:
            print("the linked is empty:not value to remove:")

        else:
            if index ==-1: # remove from the last
                value = self.front.data
                self.front = self.front.prev
                self.front.next = None
                return value
            elif index==0:
                data=self.head.data
                self.head=self.head.next
                self.head.prev=None
                self.length-=1
                return data
            else:
                temp=self.head
                index-=1
                while index:
                    temp=temp.next
                    index-=1
                data=temp.next.data
                temp.next=temp.next.next
                self.length-=1
                return data

    def setter(self,lst):
        for i in lst[::-1]:
            self.push(i)
    def reverse(self):
        pre = None
        cur = self.head
        while cur:
            _next = cur.next
            cur.next = pre
            pre = cur
            cur = _next
        self.head  = pre
    def searching(self,value_find):
        temp = self.head
        while temp.next:
            if value_find in temp.data:
                print("founded!!!")
            temp = temp.next
        else:
            if temp.data == value_find:
                print("founded!")
            else:
                print("not founded!")
    def __repr__(self):
        _str = ""
        temp = self.head
        if temp is None:
            print("null!!!")
        else:
            while temp.next:  # until my ll Node is not null and has the next so we will find the best thing in here.
                _str += str(temp.data) + "<->"
                temp = temp.next
            else:
                _str += str(temp.data)  # it is the last node of the ll and we want to refer it to the tail of the ll.
            return _str
# making the object in here to find the list.
