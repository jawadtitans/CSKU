# implementing the Array in python:
# the array should have these methods: 1) insert 2) pop() 3) extend() #index getitem() 4) length 5) append() 6)
# delete() 8)resizing() 9)
from matplotlib import pyplot as plt
from math import *

class Array:
    def __init__(self):  # the capacity in here is the whole size for dynamic array in here and it will defferent with he size of the array
        self.size = 0
        self.capacity = 30# the first time we dont have any value in the array so, it is 0
        self.array = [None]*self.capacity
    def __len__(self):
        return self.size

    def insert(self, index, value):
        try:
            if self.size == self.capacity:
                self.__resize()
            if index==0:
                self.array[0]=value
            elif not 0 < index <= self.size:
                raise Exception("invalid index")
            for i in range(self.size, index, -1): self.array[i] = self.array[i - 1]  # just shift the elements to teh right side
            self.array[index] = value
            self.size += 1
        except:
            print("invlalid index to insert!")


    def delete(self, index):
        if not 0 <= index < self.size:
            raise Exception("invalid index")
        for i in range(index, self.size - 1):
            self.array[i] = self.array[i + 1]
        self.array[self.size - 1] = None  # when all the element shifted to the left until to the index of giving so after that the last node should be none
        self.size -= 1
    def __resize(self):
        new_capacity = self.capacity * 2
        new_array = [None] * new_capacity
        for i in range(self.size):
            new_array[i] = self.array[i]
        self.array = new_array
        self.capacity = new_capacity
    def getItem(self,index):
        return self.array[index]
    def selection_sort(self, lst):
        length = len(lst)
        for i in range(length):
            min_ = i
            for j in range(i, length):
                if lst[min_] > lst[j]:
                    min_ = j
            lst[min_], lst[i] = lst[i], lst[min_]  # swap with togethers
            plt.bar(range(len(lst)), lst)
            plt.pause(0.5)
            plt.clf()
            plt.xlabel("input Size")
            plt.ylabel("Running Time:")
            plt.title("selection sort")
        print( lst)
    def insertion_sort(self,list_):
            for i in range(1, len(list_)):
                for j in range(len(list_)):
                    if list_[i] < list_[
                        j]:  # if we found any element that should be bigger than the selected element so, we just insetion gelement at the any place of elemenet that was bigger than the it.
                        temp = list_[
                            i]  # we should save this element in here into the temp variable to find the best thing in herer .
                        del list_[i]
                        list_.insert(j, temp)
                        break  # dont go forward to the whole elements of the list:
                plt.bar(range(len(list_)), list_)
                plt.pause(0.5)
                plt.clf()
            print(list_)
    def bubble_sort(self,lst):
        flag = True
        length = len(lst)
        for i in range(length - 1):
            for j in range(length - i - 1):
                if lst[j] > lst[j + 1]:
                    flag = False  # if the swapping not being in here or in any kind of sitaution in our list so we dont need to untill sort our list like this one so we hsould assign our list to Flase to find any situatio to being the sorte our lsit like this .
                    lst[j], lst[j + 1] = lst[j + 1], lst[j]  # swap between togethers to go forward next:
                plt.clf()
                plt.bar(range(len(lst)), lst)
                plt.pause(0.007)
                plt.clf()
                plt.xlabel("input Size")
                plt.ylabel("size of elements")
                plt.title("Bubble Sort")# in here we can show the plt of gui for showing how it sorted like this .
            if flag:  # it means if our flag dont not swapping in the lsit and it until neing to the True so you need to break the iteration of swapping
                break
        print(lst)

    def merge_sort_(self,list_):
        if len(list_) == 1:
            return list_  # it means if my length of the list is equal to 1:
        mid = len(list_) // 2
        lst1 = list_[0:mid]
        lst2 = list_[mid:len(list_)]
        left = self.merge_sort_(lst1)
        right = self.merge_sort_(lst2)
        plt.clf()
        plt.bar(range(len(list_)), list_)
        plt.pause(0.5)
        return self.merges(left, right)
    def merges(self,lst1,lst2):
            i = j = 0
            list_ = []
            len1 = len(lst1)
            len2 = len(lst2)
            while i < len1 and j < len2:
                if lst1[i] < lst2[j]:  # if you find any value in any of that list that was smaller than the other :
                    list_.append(lst1[i])
                    i += 1
                else:
                    list_.append(lst2[j])
                    j += 1
            list_ += lst1[i:]
            list_ += lst2[j:]
            print(list_)
    def stooge_sort(self,low,high,arr):
        if arr[low] > arr[high]:
            arr[low], arr[high] = arr[high], arr[low]

        if high - low + 1 > 2:  # second tep in here to check if the length of the array is bigger than the two elements in here.
            third = (high - low + 1) // 3  # find the third part of the array in here to cathc the infornamation inerbe

            self.stooge_sort(arr, low, high - third)
            self.stooge_sort(arr, low + third, high)
            self.stooge_sort(arr, low, high - third)
            plt.clf()
            plt.bar(range(len(arr)), arr, basefmt=' ')
            plt.pause(0.1)  # Add a delay of 0.1 seconds
            plt.title("Stooge Sort")
            plt.xlabel("input size")
            plt.ylabel("Running time:")
    def quick_sort_(self,low,high,lst):
        if low < high:  # this condition will apply if our list is being in here to find any silusion way like this ....
            pivate = low
            i = low
            j = high
            while i < j:
                while lst[i] <= lst[pivate] and i < high:
                    i += 1
                while lst[j] > lst[pivate]:
                    j -= 1
                if i < j:  # if you find both of them situation you need to run this condition like this  # if not our i<j so we should exchange the j with pivate and divide our list into two part after pivate and before pivate.
                    lst[i], lst[j] = lst[j], lst[i]
                lst[j], lst[pivate] = lst[pivate], lst[j]
                self.quick_sort_(lst, low, j - 1)
                self.quick_sort_(lst, j + 1, high)
                plt.bar(range(lst), lst)
                plt.pause(0.005)
                plt.clf()
            return lst
    def shell_sort(self,array):
        n = len(array)
        gap = n//2
        while gap > 0:
            for i in range(gap, n):
                temp = array[i]
                j = i
                while j >= gap and array[j - gap] > temp:
                    array[j] = array[j - gap]
                    j -= gap
                    plt.bar(len(range(array)),array)
                    plt.clf()
                    plt.pause(0.001)
                array[j] = temp
                plt.bar(len(range(array)), array)
                plt.clf()
                plt.pause(0.001)

            gap //= 2
        plt.sbar(len(range(array)), array)
        plt.clf()
        plt.pause(0.001)
        return array

    def binary_search(self,value,arr):
        left, right = 0, len(arr) - 1

        while left <= right:
            mid = left + (right - left) // 2

            # Check if target is present at mid
            if arr[mid] == value:
                return mid

            # If target is greater, ignore the left half
            elif arr[mid] < value:
                left = mid + 1

            # If target is smaller, ignore the right half
            else:
                right = mid - 1
        if self.binary_search(value,arr) != -1:
            print(f"Element is present at index {self.binary_search(value,arr)}")
        else:
            print("Element is not present in array")
        # Target is not present in the array
        return -1


    def linear_search(self,value,arr):
        try:
            for i in range(len(arr)):
                # Check if the current element is the target
                if arr[i] == value:
                    return i  # Return the index of the target element

                # Target is not present in the array
            if self.linear_search(value,arr)!=-1:
                print(f"Element is present at index {self.linear_search(value,arr)}")
            else:
                print("element is not found in that index")
            return -1
        except Exception as error:
            print(f"the list is Empty: as I found based on {error}")
    def jump_search(self,value,arr):
            length = len(arr)
    # Finding the block size to be jumped
            step = int(sqrt(length))
            prev = 0
            # Finding the block where element is present (if it is present)
            try:
                while arr[min(step, length) - 1] < value:
                    prev = step
                    step += int(sqrt(length))
                    if prev >= length:
                        return -1
                # Doing a linear search for target in the block beginning with prev
                while arr[prev] < value:
                    prev += 1
                    # If we reached next block or end of array
                    if prev == min(step, length):
                        return -1
                # If element is found
                if arr[prev] == value:
                    return prev
                if self.jump_search(value,arr)!=-1:
                    print(f"this is find in index:{self.jump_search(value,arr)}")
                else:
                    print(" this is not find in array:")
                return -1
            except Exception as error:
                print(f" the array is Empty based on an error Called :{error}")
    def interpolation_search(self,arr, target):
        low = 0
        high = len(arr) - 1
        try:
            while low <= high and arr[low] <= target <= arr[high]:
                # Calculate the position using interpolation formula
                pos = low + ((target - arr[low]) * (high - low)) // (arr[high] - arr[low])

                # If target is found
                if arr[pos] == target:
                    return pos

                # If target is smaller, ignore the right half
                elif arr[pos] < target:
                    low = pos + 1

                # If target is larger, ignore the left half
                else:
                    high = pos - 1
            if self.interpolation_search(arr,target)!=-1:
                print(f"this is found in index:{self.interpolation_search(arr,target)}")
            else:
                print("it is not found in taht index in here:")
            return -1
        except Exception as er:
            print(f"the Array is Empty: based on {er}")
    def display(self):
        min_= [self.array[i] for i in range(self.size) ]  # a simulation of array in here class of pythohn
        return min_

array = Array()




