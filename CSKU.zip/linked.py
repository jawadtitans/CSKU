
import random

class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
# the above example just make the node with no link or reference to the next node (just node) with data and next
class Linke_list:
    def __init__(self,capacity):
        self.length = 0
        self.capacity=capacity
        self.head=None
    def push(self,data):
        if self.length==self.capacity:
            print(" the capacity of linked list is full")
        else:# adding a node at the begin of the linked list.
            new_node=Node(data) # we made the new node in here.'
            new_node.next=self.head
            self.head=new_node
            self.length+=1
    def append(self,data):
        if self.length==self.capacity:
            print(" the capacity of linked list is full")
        else:
            new_node=Node(data)
            temp=self.head # we need to create a reference to my ll to can go over the list:
            while temp.next: # it means while we have to next in our linked-list so we just need to define it in the.
                temp=temp.next
            else:
                temp.next=new_node #it means it is the last element of the ll and it we want to add a new node at the end of the linked list .
                self.length+=1
    def __len__(self):
        length=0
        temp=self.head
        while temp.next:
            temp=temp.next
        else:
            length+=1
        return length + 1
    def is_empty_ll(self):
        return self.length==0

    def insert(self,index,data):
          if self.length ==self.capacity:
              print("the capcity of linked list is full")
          else:
              if index<=0:
                  self.push(data)

              elif index>=self.length-1:
                  self.append(data)

              else:
                  temp=pre=self.head
                  while index: # it means until the index is not arrive to my index that i have been saved in here it should go forward like this one.
                      pre=temp
                      temp=temp.next
                      index-=1
                  else:
                      new_node=Node(data)
                      new_node.next=temp
                      pre.next=new_node
                      self.length+=1
    def pop(self,index=-1):
        if index ==-1:
            temp=self.head
            while temp.next.next: # until you can access.
                temp=temp.next
            data=temp.next.data
            temp.next=None
            self.length-=1
            return data
        elif index==0:
            data=self.head.data
            self.head=self.head.next
            self.length-=1
            return data
        else:
            temp=self.head
            index-=1
            while index:
                temp=temp.next
                index-=1
            data=temp.next.data
            temp.next=temp.next.next
            self.length-=1
            return data

    def setter(self,lst):
        for i in lst[::-1]:
            self.push(i)
    def reverse(self):
        pre = None
        cur = self.head
        while cur:
            _next = cur.next
            cur.next = pre
            pre = cur
            cur = _next
        self.head  = pre
    def searching(self,value_find):
        temp = self.head
        while temp.next:
            if value_find in temp.data:
                print("founded!!!")
            temp = temp.next
        else:
            if temp.data == value_find:
                print("founded!")
            else:
                print("not founded!")
    def display(self):
        _str = ""
        temp = self.head
        if temp is None:
            print("null!!!")
        else:
            while temp.next:  # until my ll Node is not null and has the next so we will find the best thing in here.
                _str += str(temp.data) + "->"
                temp = temp.next
            else:
                _str += str(temp.data)  # it is the last node of the ll and we want to refer it to the tail of the ll.
            return _str

# making the object in here to find the list.
