from typing import List
class BST:
    def __init__(self,data):
        self.data = data
        self.left = None
        self.right=None
    def add_child(self,value):
        if value == self.data:
            return
        elif value <self.data:
            if self.left is None:
                self.left = BST(value)
            else:
                self.left.add_child(value)
        else:
            if self.right is None:
                self.right = BST(value)
            else:
                self.right.add_child(value)
    def delete(self,child):
        pass
    def leaf_display(self):
        pass
    def get_height(self):
        pass
    def get_path_length(self,source_node,destination_node):
        pass
    def is_root(self,p):
        pass
    def is_parent(self,p):
        pass
    def search(self,find):
        if self.data == find:
            return True
        elif self.data<find:
           if self.right:
               return self.right.search(find)
           return False
        else:
            if self.left:
                return self.left.search(find)
            return False
    def reverse(self):
      self.right ,self.left = self.left,self.right
      if self.left:
          return self.left.reverse()
      if self.right:
          return self.right.reverse()
    def display(self):
        lines, *_ =self.display_aux()
        return lines
    def display_aux(self):
        if self.right is None and self.left is None:
            line = '%s' % self.data
            width = len(line)
            height = 1
            middle = width // 2
            return [line], width, height, middle

        # Only left child.
        if self.right is None:
            lines, n, p, x = self.left._display_aux()
            s = '%s' % self.data
            u = len(s)
            first_line = (x + 1) * ' ' + (n - x - 1) * '_' + s
            second_line = x * ' ' + '/' + (n - x - 1 + u) * ' '
            shifted_lines = [line + u * ' ' for line in lines]
            return [first_line, second_line] + shifted_lines, n + u, p + 2, n + u // 2

        # Only right child.
        if self.left is None:
            lines, n, p, x = self.right._display_aux()
            s = '%s' % self.data
            u = len(s)
            first_line = s + x * '_' + (n - x) * ' '
            second_line = (u + x) * ' ' + '\\' + (n - x - 1) * ' '
            shifted_lines = [u * ' ' + line for line in lines]
            return [first_line, second_line] + shifted_lines, n + u, p + 2, u // 2

        # Two children.
        left, n, p, x = self.left._display_aux()
        right, m, q, y = self.right._display_aux()
        s = '%s' % self.data
        u = len(s)
        first_line = (x + 1) * ' ' + (n - x - 1) * '_' + s + y * '_' + (m - y) * ' '
        second_line = x * ' ' + '/' + (n - x - 1 + u + y) * ' ' + '\\' + (m - y - 1) * ' '
        if p < q:
            left += [n * ' '] * (q - p)
        elif q < p:
            right += [m * ' '] * (p - q)
        zipped_lines = zip(left, right)
        lines = [first_line, second_line] + [a + u * ' ' + b for a, b in zipped_lines]
        return lines, n + m + u, max(p, q) + 2, n + u // 2
    """ traversing the binary search Tree """
    def in_order_traverse(self):
        elements = []
        if self.left:
            elements +=self.left.traverse()
        elements.append(self.data)
        if self.right:
            elements+=self.right.traverse()

    def post_order_travsers(self):
        elements = []
        if self.left:
            elements+=self.left.traverse()
        if self.right:
            elements+=self.right.traverse()
        elements.append(self.data)
    def pre_order_traverse(self):
        elements = []
        elements.append(self.data)
        if self.left:
            elements+=self.left.traverse()
        if self.right:
            elements+=self.right.traverse()

    def get_inorder_to_dispaly(self, elements_in_order_t: List):
        pass

    def get_pre_order_to_display(self, elements_pre_order_t: List):
        pass

    def get_post_order_to_display(self, elemets_post_order_t: List):
        pass


