class General_tree:
    def __init__(self,value):
        self.value = value
        self.children = []
        self.level =0
        self.parent =None
    def addChild(self,child):
        self.children.append(child)
        child.parent = self
    def __remove_(self,child):
        return
    def display(self):
        space = "   "*self.get_level()
        prefix = space+"|--" if self.parent else"|--"
        print(prefix,self.value)
        for child in self.children:
            child.display()
        return prefix
    def get_level(self):
        level = 0
        p = self.parent
        while p:
            level +=1
            p = p.parent
        return level
    def height(self):
        if len(self.children)==0:
            return 0
        max_heigth = -1
        for child in self.children:
            max_heigth = max(max_heigth,child.height())
        return max_heigth+1
    def search_child(self,find):
        if self.value == find:
            return True
        for child in self.children:
            founder =child.search_child(find)
            if founder:
                return True
            return False
    def traverse(self):
        pass
    def Is_binary(self):
        if len(self.children)>2:
            return False
        if len(self.children)==0:
            return True
        for child in self.children:
            if not child.Is_binary():
                return False
            return True






