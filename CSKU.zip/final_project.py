import tkinter as tk
from tkinter import ttk, messagebox

import PIL.Image
import customtkinter
from PIL import ImageTk
from customtkinter import CTkImage
import os
import Linked_list
import doubly_linked_list
import general_tree
from aray import *
from binary_search_tree import BST
from general_tree import *
LARGEFONT = ("Verdana", 35)
import customtkinter as ctk
customtkinter.set_appearance_mode("system")
customtkinter.set_default_color_theme('dark-blue')
import linked

class DSA:
    def __init__(self):
        # simply linked _list ==========
        self.childrens = []
        self.get_types = 0
        self.capacity_linked_list = 0
        self.length_linked_list = 0
        self.index = 0
        self.head=None
        self.next = None
        # doubly linked list ===============
        self.value = 0
        self.capacity_doubl_linkee_list =0
        self.get_count_addition_linked_list = 0
        self.count_remove = 0
        self.length_doubly = 0
        self.head_doubly = None
        self.next_doubly = None
        self.prev = None
        self.index_doubly = 0
        self.value_doubly = 0
        self.get_count_addition_doubly_linked_list = 0
        self.count_remove_doubly = 0
        # array ===================
        self.array_capacity = 0
        self.size_insert=0
        self.types =""
        self.reqiure_array = None
        # stack requirements:
        self.size = None
        self.top = -1
        self.length = 0
        self.count_push = 0
        self.count_pop = 0
        # Queue requirements.the requirement and the most importrtant for this class :
        self.front = 0
        self.tail = -1
        self.size_queue = 0
        self.count_enqueue = 0
        self.dequeu = 0
        self.length_queue = 0
    def ragister(self):
        FILENAME="user_info.txt"
        if FILENAME:
            if os.path.exists(FILENAME):
                if os.path.getsize(FILENAME)==0: # if the file is Empty so, we need to go for the sign up file to fill by the GUI in here:!!!!
                    self.window = ctk.CTk()
                    self.window.title("downloader")
                    self.window.geometry("925x500+300+200")
                    self.window.resizable(False, False)
                    ctk.CTkLabel(self.window, text="Final DSA Project ",
                                 font=("Microsoft Yahei UI Light", 30, "bold")).place(x=110, y=100)
                    self.frame = ctk.CTkFrame(self.window, width=350, height=350)
                    ctk.CTkLabel(self.window, text="programmed by Elliot Rahimi",
                                 font=("Microsoft Yahei UI Light", 16, "bold")).place(
                        x=120, y=140)
                    self.frame.place(x=480, y=70)
                    self.heading_label = ctk.CTkLabel(self.window, text="Register",
                                                      font=("Microsoft Yahei UI Light", 26, "bold"))
                    self.heading_label.place(x=600, y=30)
                    self.User_get = ctk.StringVar()
                    self.User = ctk.CTkEntry(self.frame, width=300, border_width=0, bg_color="black",textvariable=self.User_get,
                                             font=("Microsoft Yahei UI Light", 11, "bold"))

                    def on_enter(e):
                        self.User.delete(0, "end")
                    def on_leave(e):
                        name = self.User.get()
                        if name == "":
                            self.User.insert(0,
                                             "username")  # it means if the username homeis nothing on here it meadn if it be empty tso onthat tiemti should be filled with uerrname hme on here time:
                    self.User.bind("<FocusIn>", on_enter)
                    self.User.bind("<FocusOut>", on_leave)
                    self.User.place(x=25, y=80)
                    self.User.insert(0, "Username")
                    self.Passw_get = ctk.StringVar()
                    self.Password = ctk.CTkEntry(self.frame, border_width=0, width=300, border_color="black",textvariable=self.Passw_get,
                                                 font=("Microsoft Yahei UI Light", 11, "bold"))
                    self.Password.place(x=25, y=220)
                    self.Password.insert(0, "Password")

                    def on_enter(e):
                        self.Password.delete(0, "end")

                    def on_leave12(e):
                        if self.Password == "":
                            self.Password.insert(0, "password")
                    self.Password.bind("<FocusIn>", on_enter)
                    self.Password.bind("<FocusOut>", on_leave12)
                    self.email_get = ctk.StringVar()
                    self.Email_user = ctk.CTkEntry(self.frame, border_width=0, width=300, border_color="black",textvariable=self.email_get,
                                                   font=("Microsoft Yahei UI Light", 11, "bold"))


                    self.Email_user.place(x=25, y=150)
                    self.Email_user.insert(0, "Email")

                    def on_enter(e):
                        self.Email_user.delete(0, "end")

                    def on_leave12(e):
                        if self.Email_user == "":
                            self.Email_user.insert(0, "Email")

                    self.Email_user.bind("<FocusIn>", on_enter)
                    self.Email_user.bind("<FocusOut>", on_leave12)

                    def sign_up():
                        self.registered_username = self.User.get()
                        self.email = self.Email_user.get()
                        self.password = self.Password.get()
                        # print(self.registered_username,self.email,self.password)
                        with open(FILENAME, '+a') as file:
                            file.write(f"{self.registered_username}\n{self.email}\n{self.password}")
                            self.window.destroy()
                            return self.requirement_inputs()
                    ctk.CTkButton(self.frame, width=300, text="sign in", command=sign_up).place(x=25, y=290)
                    self.window.mainloop()
                else: # if not empty the file of handling in here:
                    return self.login()
            else: # if the user_info.txt file is not being in here what should I do and how i criticize this issue in here
                file=open("login_user.txt","+a") # file will create in this path that you are and will operate in here in this file that it has been created!
                file.write(f"{self.registered_username}")
                self.email = input("Enter your Email:")
                self.password = input("Enter your password")
                return self.requirement_inputs()
    def login(self):
        FILENAME="user_info.txt"
        with open(FILENAME, 'r') as file:
            self.window = ctk.CTk()
            self.window.title("DSA Project")
            # self.root.iconphoto(True)
            self.window.geometry("925x500+300+200")
            self.window.resizable(False, False)
            ctk.CTkLabel(self.window, text="Final DSA Project ", font=("Microsoft Yahei UI Light", 30, "bold")).place(
                x=120, y=100)
            self.frame = ctk.CTkFrame(self.window, width=350, height=350)
            ctk.CTkLabel(self.window, text="programmed by Elliot Rahimi",font=("Microsoft Yahei UI Light", 16, "bold")).place(
                x=120, y=140)
            self.frame.place(x=480, y=70)
            self.heading_label = ctk.CTkLabel(self.window, text="Sign In", font=("Microsoft Yahei UI Light", 26, "bold"))
            self.heading_label.place(x=610, y=30)
            self.user_get = ctk.StringVar()
            self.User = ctk.CTkEntry(self.frame, width=300, border_width=0, bg_color="black",textvariable=self.user_get,font=("Microsoft Yahei UI Light", 11, "bold"))
            def on_enter(e):
                self.User.delete(0, "end")

            def on_leave(e):
                name = self.User.get()
                if name == "":
                    self.User.insert(0,"username")  # it means if the username homeis nothing on here it meadn if it be empty tso onthat tiemti should be filled with uerrname hme on here time:
            self.User.bind("<FocusIn>", on_enter)
            self.User.bind("<FocusOut>", on_leave)
            self.User.place(x=25, y=80)
            self.User.insert(0, "Username")
            self.password_get = ctk.StringVar()
            self.Password = ctk.CTkEntry(self.frame, border_width=0, width=300, border_color="black",textvariable=self.password_get,font=("Microsoft Yahei UI Light", 11, "bold"))
            self.Password.place(x=25, y=150)
            self.Password.insert(0, "Password")

            def on_enter(e):
                self.Password.delete(0, "end")

            def on_leave12(e):
                if self.Password == "":
                    self.Password.insert(0, "password")
            self.Password.bind("<FocusIn>", on_enter)
            self.Password.bind("<FocusOut>", on_leave12)
            self.registered_username = file.readline().split()
            self.email_ = file.readline().split()
            self.password_ = file.readline().split()

            def sign_in():
                self.username = self.user_get.get()
                self.password_user = self.password_get.get()
                if self.username == self.registered_username[0]  and self.password_user == self.password_[0]:
                    text_success = ctk.CTkLabel(self.frame,text=f"Login successful. Welcome back {self.username}",text_color="green")
                    text_success.place(x=25,y=320)
                    self.window.destroy()
                    return self.requirement_inputs()
                else:
                    text_success = ctk.CTkLabel(self.frame, text=f"incorrect information! {self.username}",text_color="red")
                    text_success.place(x=75, y=320)
            ctk.CTkButton(self.frame, width=300, text="sign in", command=sign_in).place(x=25, y=204)
            self.window.mainloop()
    def requirement_inputs(self):
        global value, root
        self.show_requirement = input("please Enter one option to start:\n1)Liner DSA\n2)non-Liner DSA\n>>>")
        if self.show_requirement == "1":
            self.info = input(f"choice one option:\n1)ARRAY\n2)STACK\n3)QUEUE\n4)LINKED-LIST\n5)HEAP\n6)EXIT()\n>>>")
            if self.info == "1":
                while True:
                    self.array_info = input("1)Definition\n2)structure\n3)exit\n>>>")
                    if self.array_info == "1":
                            definiation_array = "definition: array is a collection of data accessible by Index."
                            show_array = "[*,*,*,*,*]"
                            print(definiation_array, f"\n{show_array}")
                            while True:
                                back = input("do you want to continue? 1)-YES       2)-NO\n>>>")
                                if back == "Y".lower():
                                    break  # go back to the array_info and retake the information of array.
                                else:
                                    return f"for exiting of program please Enter: exit() in the terminal."  # exit() program :
                    elif self.array_info == "2":
                        self.types = input("Enter the type of array to implement:\n1)-int\n2)Str\n3)float") # it will save this value and when you wanna insert any value in your array it will authenticate which type of data you have to insert into array just about insert operation :
                        while True:
                            if array:
                                 self.reqiure_array = input(
                                    "which operation would you like to implement:\n1)insert \n2)delete\n3)access\n4)display\n5)sorting\n6)searching\n7)exit()")
                            else:
                                self.array_capacity = int(input("Enter the capacity of the array:"))
                                self.reqiure_array = input(
                                    "which operation would you like to implement:\n1)insert \n2)delete\n3)access\n4)display\n5)sorting\n6)searching\n7)exit()")
                            if self.reqiure_array == "1":
                                    self.size_insert=int(input("how many data do you wanna insert into index:"))
                                    i=0
                                    while i<=self.size_insert:
                                        if self.types =="1":
                                            array.insert(int(input("index:")),int(input(f"value:")))
                                            i+=1
                                            if i==self.size_insert:
                                                quest = input("do you wanna Display:   1.Y          2.N")
                                                if quest == "y".lower():
                                                    print(array.display())
                                                    break
                                            else:
                                                pass
                                        elif self.types=="2":
                                            array.insert(int(input("Index: ")),input("which string:"))
                                            i+=1
                                            if i==self.size_insert:
                                                 quest = input("do you wanna Display:   1.Y          2.N")
                                                 if quest == "y".lower():
                                                    print(array.display())
                                                    break
                                        elif self.types=="3":
                                            array.insert(int(input("Index: ")),float(input("which float number:")))
                                            i+=1
                                            if i==self.size_insert:
                                                 quest = input("do you wanna Display:   1.Y          2.N")
                                                 if quest == "y".lower():
                                                    print(array.display())
                                                    break
                                        else:
                                            print("invalid input!")
                                            break

                            elif self.reqiure_array == "2":  # -------------------remove the elements---------------------
                                question = int(input("how many time do you like to remove:"))
                                m=0
                                while m<question:
                                    array.delete(int(input("which index to remove")))
                                    m+=1
                                    if m==question:
                                        continues_remove = input("do you wanna display? 1)-YES            2)-No")
                                        if continues_remove == "Y".lower():
                                            print(array)
                                    else:
                                        pass
                            elif self.reqiure_array == "3":  # accessing any elements in the array:
                                index_acces = int(input("Enter the index to access:"))
                                value = array.display()[index_acces]
                                print(value)
                            elif self.reqiure_array == "4":  # display the array:
                                print(array.display())
                            elif self.reqiure_array == "5":  # sotrting of array in
                                require=input("which searching do you wanna implement:\n1. selection sort\n2. insertion sort\n3. quick sort\n4. bubble_sort \n5. Merge sort\n6. stooge sort\n7)shell sort")
                                if require=='1':
                                    print(array.selection_sort(array.display()))
                                elif require=="2":
                                    array.insertion_sort(array.display())
                                elif require=='3':
                                    array.quick_sort(array.display()[0],array.display()[len(array.display()-1)],array.display())
                                elif require=="4":
                                    array.bubble_sort(array.display())
                                elif require=='5':
                                    array.merge_sort_(array.display())
                                elif require=="6":
                                    array.stooge_sort(array.display()[0],array.display()[len(array.display()-1)],array.display())
                                elif require=="7":
                                    array.shell_sort(array.display())
                                else:
                                    print("invalid input!!!")
                            elif self.reqiure_array=="6": # searching
                                self.require_searching=input("which searching do you wanna implement:\n1. linear search\n2.  binary search")
                                if self.require_searching=="1":
                                    array.linear_search(array.display(),int(input("which value do you wanna find:")))
                                elif self.require_searching=="2":
                                    array.binary_search(array.display(),int(input("Which value do you wanna find:")))
                                elif self.require_searching=="3":
                                    array.jump_search(array.display(),int(input("which value do you wanna find:")))
                                elif self.require_searching =="4":
                                    array.interpolation_search(array.display(),int(input("which value do you wanna find:")))
                                else:
                                    print("invalid input!!!")
                            elif self.reqiure_array=="7":
                                self.returnable = input(" do you wanna come back to the array information specification ?\nY\nN")
                                if self.returnable =="y".lower():
                                    return self.array_info
                                else:
                                    return self.reqiure_array
                            else:
                                print("invalid input please try again!!!")
                                break
                    elif self.array_info == "3":
                            self.required_exit= input("Do you wanna came back to the data structure Specifiction? \nY\nN")
                            if self.required_exit=="Y".lower():
                                return self.array_info
                            else:
                                return self.array_info

                            """ ------------------> STACK OPERATION --------------------------"""

            elif self.info == "2":  # stack operations and definition. <------ the stack operartion Start from here and you can choice one of them in Jere.
                self.size = int(input("Enter your stack size:")) # this is the capacity of our stack:
                self.stack = [None] * self.size # create the stack in here as A None value to initalization of the valuee;
                print("stack have been created successfully!!")
                while True:
                    self.Stack_info = input("1)Definition\n2)structure\n3)exit")
                    if self.Stack_info == "1":
                        definiation_Stack = "definition-Stack: stack is a collection of elements that are inserted and removed according to LIFO-Principle, meaning to last in first out."
                        show_Stack = "[first Elements,..........,last-elements]" # =>LIFO=> 
                        print(definiation_Stack, f"\n{show_Stack}")
                        while True:
                            back = input("do you want to continue? 1)-YES       2)-No")
                            if back == "Y".lower():
                                break  # go back to the stack_info and retake the information of Stack.
                            else:
                                return f"for exiting of program please Enter: exit() in the terminal."  # exit() program :
                    elif self.Stack_info == "2":  # their structure in here to be implemented....
                        while True:
                            self.reqiure_Stack = input(
                                "which operation would you like to implement in Stack:\n1)push \n2)pop\n3)peek\n4)display-stack\n5)is-Empty\n6)Is-full\n7)len\n8)exit()")
                            if self.reqiure_Stack == "1":
                                self.count_push = int(input("Enter the count of push operation in stack:"))
                                if self.count_push + self.length > self.size:
                                    print(" you can not Enter over the size of stack please Enter less than the size of stack in here.")
                                i = 0
                                while i < self.count_push:
                                    if self.length == self.size:  # continue until ti become the full size.
                                        print("your stack's Size is full,")
                                        break
                                    self.top += 1
                                    self.stack[self.top] = int(input(f"Value:{i}"))
                                    self.length += 1
                                    i += 1
                                request = input( " do you wanna displayed the Stack right now Or not:     1)-YES                 2)-NO")
                                if request == "Y".lower():
                                    print(self.stack)
                                elif request == "N".lower():
                                    continues2 = input(
                                        "do you wanna continue implementation on stack?      1)-YES            2)-No")
                                    if continues2 == "Y".lower():
                                        break
                                    else:
                                        print( f"Enter exit() in terminal:")
                                else:
                                    print("invalid Index")
                                    break
                            elif self.reqiure_Stack == "2":  # <----------- remove the elements -------------->
                                if self.length == 0:
                                    print(
                                        "can not do pop operation because the stack is Empty: please before this method insert any values and then implement this one.")
                                    break
                                self.count_pop = int(input("Enter the count of pop operation:"))
                                if self.count_pop > self.size:
                                    print(
                                        "you can not Enter the count of pop operation bigger than the size of stack as you have been defined before:")
                                    break
                                k = self.count_pop
                                while k > 0:

                                    if self.length == 0:  # if it be Empty so,
                                        print(" your size of stack is Empty please implement another methods:like push")
                                        break
                                    value = self.stack[self.top]
                                    self.length -= 1
                                    self.stack[self.top] = None
                                    self.top -= 1
                                    k -= 1
                                    print(value)
                                    if k==self.count_pop:
                                        continues2 = input(
                                            "do you wanna continue implementation on stack?      1)-YES            2)-No")
                                        if continues2 == "Y".lower():
                                            break
                                        else:
                                            print(f"Enter exit() in terminal:")
                                            break
                            elif self.reqiure_Stack == "3":  # accessing any elements in the stack:
                                if self.stack == 0:
                                    print("can not take the last element of stack because of it is empty:")
                                    break
                                else:
                                    print(self.stack[self.top], f"\n{self.stack}")
                                continues_remove = input(
                                    "do you wanna continue another operation? 1)-YES            2)-No")
                                if continues_remove == "Y".lower():
                                    break
                                else:
                                    return f"enter the exit() in terminal:"
                            elif self.reqiure_Stack == "4":  # display the stack:
                                print(f"Stack:{self.stack}")
                                continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                if continues_remove == "Y".lower():
                                    break
                                else:
                                    return f"enter the exit() in terminal:"
                            elif self.reqiure_Stack == "5":  # <----------- SI_Empty Method -------->
                                if self.length == 0:
                                    print(True)
                                    continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                    if continues_remove == "Y".lower():
                                        break
                                    else:
                                        return f"enter the exit() in terminal:"
                                else:
                                    print(False)
                                    continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                    if continues_remove == "Y".lower():
                                        break
                                    else:
                                        return f"enter the exit() in terminal:"
                            elif self.reqiure_Stack == "6":  # <---------------- Is _Full Method --------------->,,,,,,,,,,,,,,,,,,,,,
                                print(self.length == self.size)
                                continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                if continues_remove == "Y".lower():
                                    break
                                else:
                                    return f"enter the exit() in terminal:"
                            elif self.reqiure_Stack == "7":  # <------------------- length of the stack ------------>
                                print(self.length)

                    elif self.Stack_info == "3":  # -<------------------------ Exit the Stack data Structure ---------->
                        self.requrired = input("Do you wanna come back to the data structure specification ?\nY\nN")
                        if self.requrired=="y".lower():
                            break
                            # return self.info
                        else:
                            return self.Stack_info
                        
                        print(f"you have been exited successfully!{requrired}")
            elif self.info == "3":  # <--------------- QUeue implemenation in here to show the best state in here according to the best
                self.capacity = int(input("Enter your Queue Capacity:"))
                self.Queue = [None] * self.capacity
                print("Queue have been created successfully!!")
                while True:
                    queue_info = input("1)Definition\n2)structure\n3)exit")
                    if queue_info == "1":
                        definiation_Queue = "definition-Queue: queue is a collection of elements that has the (LILO or FIFO)-Principle, meaning to last in last out."
                        show_Queue = "[first-element,...........last-element]" # FIFO =>LILO
                        print(definiation_Queue, f"\n{show_Queue}")
                        while True:
                            back = input("do you want to continue? 1)-YES       2)-No")
                            if back == "Y".lower():
                                break  # go back to the stack_info and retake the information of Stack.
                            else:
                                return f"for exiting of program please Enter: exit() in the terminal."  # exit() program :
                    elif queue_info == "2":  # their structure in here to be implemented....
                        while True:
                            reqiure_Queue = input(
                                "which operation would you like to implement in queue:\n1)enqueu \n2)dequeue\n3)peek\n4)display-Queue\n5)is-Empty\n6)Is-full\n7)len\n8)exit()")
                            if reqiure_Queue == "1":
                                self.count_enqueue = int(input("Enter the count of Enqueue operation in Queue:"))
                                if self.count_enqueue + self.length_queue > self.capacity:
                                    print(
                                        " your value that you have been Entred is over the size of the Queue please enter lessablesuiY:")
                                i = 0
                                while i < self.count_enqueue:
                                    if self.Queue == self.top:  # continue until ti become the full size.
                                        print("your queue's Size is full,")
                                        exit()
                                    self.top += 1           # [1,2,3,4,5,6] =
                                    self.Queue[self.top] = int(input(f"Value:{i}"))
                                    self.length_queue += 1
                                    i += 1
                                print(self.Queue)
                                continues2 = input("do you wanna continue?      1)-YES            2)-No")
                                if continues2 == "Y".lower():
                                    break
                                else:
                                    return f"Enter exit() in terminal:"
                            elif reqiure_Queue == "2":  # dequeue the elements
                                if self.Queue == 0:
                                    print("can not do dequeue operation because the stack is Empty:")
                                    break
                                count_dequeue = int(input("Enter the count of dequeue operation:"))
                                k = 0
                                while k < count_dequeue:
                                    if self.Queue == 0:
                                        print(" your size of queue is Empty:")
                                        break
                                    value = self.Queue[self.front]
                                    self.Queue[self.front] = None
                                    self.front = (self.front + 1) % len(self.Queue) #=> 0+1=>1
                                    self.length_queue -= 1
                                    k += 1
                                    print(value)
                                print(self.Queue)
                                continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                if continues_remove == "Y".lower():
                                    break
                                else:
                                    return f"enter the exit() in terminal:"
                            elif reqiure_Queue == "3":  # accessing any elements in the Queue:
                                if self.length_queue == 0:
                                    print("can not take the last element of stack because of it is empty:")
                                    break
                                else:
                                    print(self.Queue[self.top])
                                    continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                    if continues_remove == "Y".lower():
                                        break
                                    else:
                                        return f"enter the exit() in terminal:"
                            elif reqiure_Queue == "4":  # display the Queue:
                                print(f"Stack:{self.Queue}")
                                continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                if continues_remove == "Y".lower():
                                    break
                                else:
                                    return f"enter the exit() in terminal:"
                            elif reqiure_Queue == "5":
                                if self.length_queue == 0:
                                    print(True)
                                    continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                    if continues_remove == "Y".lower():
                                        break
                                    else:
                                        return f"enter the exit() in terminal:"
                                else:
                                    print(False)
                                    continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                    if continues_remove == "Y".lower():
                                        break
                                    else:
                                        return f"enter the exit() in terminal:"

                            elif reqiure_Queue == "6":
                                print(self.length_queue == self.capacity)
                                continues_remove = input("do you wanna continue? 1)-YES            2)-No")
                                if continues_remove == "Y".lower():
                                    break
                                else:
                                    return f"enter the exit() in terminal:"
                            elif reqiure_Queue == "7":
                                return self.length_queue
                    elif queue_info == "3":
                        requrired = input("enter to the terminal exit() to exit:")
                        print(f"you have been exited successfully!{requrired}")
            elif self.info == "4":  # another type of liner data structure in here. linked list;;;;;<----------------------  LINKED LIST  -------------------------------------
                linked_info = input(
                    "Which kind of linked list do you want to Implement:\n1)Simply linked List\n2)doubly linked List\n3)circulary linked list")
                if linked_info == "1":
                    while True:
                        self.information_linked = input("which Structure do you want:\n1)definition\n2)structure\n3)exit()")
                        if self.information_linked == "1":
                            difination = "the simplay linked list is a collection of nodes that has a reference to each node that have been two properties to the "
                            print(difination)
                            print("a->b->c->d->e\na(Node=>has value and reference (next->))\na(head)\ne(tail)")
                        elif self.information_linked == "2":
                            self.capacity_linkee_list = int(input("Enter the capacity of linked list:"))
                            ll=linked.Linke_list(self.capacity_linkee_list)
                            print("the linked list have been created successfully!!!")
                            self.structres_linked_lsit = input(
                                "which operation do you like to implement in linked list:\n1)Adding\n2)removing\n3)displaying\n4)is_full\n5)is_empty\n6)reversing\n7)searching\n8)exit()")
                            while True:

                                if self.structres_linked_lsit == "1":  #<--------- insert node --------------------->
                                    if self.get_count_addition_linked_list:
                                        print("you have been added some value in your linked list before:")
                                        if not ll.is_empty_ll():
                                            readded =(input("do you like to add another values in you linked list. yes or not:"))
                                            if readded=="YES".lower():
                                                break
                                            else:
                                                break
                                    self.get_count_addition_linked_list = int(input("How many values do you want to insert with their Index:"))
                                    im = 0
                                    while im < self.get_count_addition_linked_list:
                                           if ll.length==ll.capacity:
                                               print("the liked list is full")
                                               break
                                           else:
                                               ll.insert(int(input("index:")),int(input("\nvalue:")))
                                               im+=1
                                               if im==self.get_count_addition_linked_list:
                                                   try:
                                                       question =input("do you wanna displayed!: 1)YES            2)NO")
                                                       if question=="1".lower():
                                                           print(ll.display())
                                                       else:
                                                           break
                                                   except Exception as e:
                                                       print(" invalid input!!!")

                                if self.structres_linked_lsit == "2": # -----> it has been worked ------------------
                                    self.count_remove = int(input("Enter the count of remove to be implemented in your linked list :"))
                                    counter = 0
                                    while counter < self.count_remove:
                                            index = int(input("Which index do you wanna remove:"))
                                            if index <= 0:  # remove from the beginning :
                                                print(ll.pop(index))
                                                counter+=1
                                            elif index == ll.length - 1:
                                                print(ll.pop(index))
                                                counter+=1
                                            elif 1 <= index <ll.length:
                                                print(ll.pop(index))
                                                counter+=1
                                            elif index>ll.length:
                                                print("out of range based on length!")
                                                break
                                            elif index==ll.length:
                                                print(ll.pop(index))
                                                counter+=1
                                            if counter==self.count_remove:
                                                quest =("do you wanna contini: 1_ yes      2) no")
                                                if quest=="YEs".lower():
                                                    break
                                                else:
                                                    print("Enter the exit in terminla :")
                                elif self.structres_linked_lsit == "3":
                                    print(ll.display())
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        return self.structres_linked_lsit
                                    else:
                                        print("pleae Enter the exit() to exit form the program of structure in here")
                                elif self.structres_linked_lsit == "4":
                                    print(ll.length==ll.capacity)
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        return self.structres_linked_lsit
                                    else:
                                        print("pleae Enter the exit() to exit form the program of structure in here")
                                elif self.structres_linked_lsit == "5":
                                    print(ll.length==0)
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        return self.structres_linked_lsit
                                    else:
                                        print(
                                            "pleae Enter the exit() to exit form the program of structure in here")
                                elif self.structres_linked_lsit == "6":
                                    ll.reverse()
                                    print(ll.display())
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        return self.structres_linked_lsit
                                    else:
                                        print(
                                            "pleae Enter the exit() to exit form the program of structure in here")
                                elif self.structres_linked_lsit == "7":
                                    value_find = int(input("Which Node do you wanna find?:"))
                                    ll.searching(value_find)
                                elif self.structres_linked_lsit == "8":
                                    print("Enter the exit() to exit from the program inhere:")
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                         break
                                    else:
                                        print(
                                            "pleae Enter the exit() to exit form the program of structure in here")
                        elif self.information_linked == "3":
                            print("please Enter the exit() to exit from the program in here:")
                elif linked_info == "2":  # <---------------------- doubly linked list in here ---------------------------->
                    while True:
                        self.information_linked = input("which Structure do you want:\n1)definition\n2)structure\n3)exit()")
                        if self.information_linked == "1":
                            difination = "the doubly linked list is a collection of nodes that has a reference to each node that have been two properties to the "
                            print(difination)
                            print("a<->b<->c<->d<->e\na(Node=>has value and reference (next->))\na(head)\ne(tail)")
                        elif self.information_linked=="2":
                            self.capacity_doubl_linkee_list = int(input("Enter the capacity of linked list:"))
                            ll = doubly_linked_list.doubly_Linke_list(self.capacity_doubl_linkee_list)
                            print("the double linked list have been created successfuly!!!")
                            while True:
                                self.structres_linked_lsit = input(
                                    "which operation do you like to implement in linked list:\n1)Adding\n2)removing\n3)displaying\n4)is_full\n5)is_empty\n6)reversing\n7)searching\n8)exit()")
                                if self.structres_linked_lsit == "1":  # <--------- insert node --------------------->
                                    if self.get_count_addition_linked_list:
                                        print("you have been added some value in your linked list before:")
                                        if not ll.is_empty_ll():
                                            readded = (
                                                input("do you like to add another values in you linked list. yes or not:"))
                                            if readded == "YES".lower():
                                                return self.get_count_addition_linked_list
                                            else:
                                                break
                                    self.get_count_addition_linked_list = int(
                                        input("How many values do you want to insert with their Index:"))
                                    im = 0
                                    while im < self.get_count_addition_linked_list:
                                        if ll.length == ll.capacity:
                                            print("the liked list is full")
                                            return self.structres_linked_lsit
                                        else:
                                            ll.insert(int(input("index:")), int(input("\nvalue:")))
                                            im += 1
                                            if im == self.get_count_addition_linked_list:
                                                question = input("do you wanna displayed!: 1)YES            2)NO")
                                                if question == "1".lower():
                                                    print(ll)
                                                else:
                                                    break
                                if self.structres_linked_lsit == "2":  # -----> it has been worked ------------------
                                    self.count_remove = int(input("Enter the count of remove to be implemented in your linked list :"))
                                    counter = 0
                                    while counter < self.count_remove:
                                        index = int(input("Which index do you want to remove:"))
                                        print(ll.pop(index))
                                        counter+=1
                                        if counter == self.count_remove:
                                            quest = ("do you wanna contini: 1_ yes      2) no")
                                            if quest == "YEs".lower():
                                                return
                                elif self.structres_linked_lsit == "3":
                                    print(ll)
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        break
                                    else:
                                        print("pleae Enter the exit() to exit form the program of structure in here")
                                elif self.structres_linked_lsit == "4":
                                    print(ll.length == ll.capacity)
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        break
                                    else:
                                        print("pleae Enter the exit() to exit form the program of structure in here")
                                elif self.structres_linked_lsit == "5":
                                    print(ll.length == 0)
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        break
                                    else:
                                        print(
                                            "pleae Enter the exit() to exit form the program of structure in here")
                                elif self.structres_linked_lsit == "6":
                                    ll.reverse()
                                    print(ll)
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        break
                                    else:
                                        print(
                                            "pleae Enter the exit() to exit form the program of structure in here")
                                elif self.structres_linked_lsit == "7":
                                    value_find = int(input("Which Node do you wanna find?:"))
                                    ll.searching(value_find)
                                elif self.structres_linked_lsit == "8":
                                    print("Enter the exit() to exit from the program inhere:")
                                    continue_q = input("do you want to continuee: 1)YES         2)NO")
                                    if continue_q == "Y".lower():
                                        break
                                    else:
                                        print("pleae Enter the exit() to exit form the program of structure in here")

                        elif self.information_linked == "3":
                              print("enter the exit to terminal for exiting")

                elif linked_info =="3": # circularly linked list
                    while True:
                        self.information_linked = input("which Structure do you want:\n1)definition\n2)structure\n3)exit()")
                        if self.information_linked == "1":
                            difination = "the circulary linked list is a collection of nodes that has a reference to each node that have been two properties to the "
                            print(difination)
                            print("a->b->c->d->e->a\na(Node=>has value and reference (next->))\na(head)\ne(tail)")
                        elif self.information_linked=="2":
                            self.capacity_doubl_linkee_list = int(input("Enter the capacity of linked list:"))
                            ll = doubly_linked_list.doubly_Linke_list(self.capacity_doubl_linkee_list)
                            print("the double linked list have been created successfuly!!!")
                        else:
                            break
            # non Linear Data strutre came after this part like this one:
        if self.show_requirement == "2":
            while True:
                self.get_types = input("Enter one option:\n 1). Tree \n2). Graph\n>>>")
                if self.get_types == "1":
                    while True:
                        self.tree_option = input("which tree do you wanna implement:\n1). general Tree\n2). Binary Search Tree \n3). AVL\n>>>")
                        if self.tree_option == "1":
                            while True:
                                self.get_details = input("which one: \n1). definition\n2). structure\n3). others\n4). exit\n>>>")
                                if self.get_details == "1":
                                    while True:
                                        definition = "A tree is an abstract data type that stores elements hierarchically."
                                        print(definition)
                                        get_more_details = input(" do you wanna more details(y) -> or back(q) ")
                                        if get_more_details == "y".lower():
                                            details_tree= '"With the exception of the top element , each element in a tree has a parent\n element and zero or more children elements\n  A tree is usually visualized by placing elements inside\novals or rectangles, and by drawing the connections between parents and children\nwith straight lines We typically call the top element the root\nof the tree, but it is drawn as the highest element."'
                                            print(details_tree)
                                        else:
                                            break
                                elif self.get_details =="2":
                                    while True:
                                        if self.root is None:
                                            print(" before start the operations you have to create your general tree in here:")
                                            self.data_types1 = input("Enter the data type to Enter: \n1). int\n2). str\n>>>") # just for Insert the data we need it
                                            self.create_G_tree = {"name":input("name Tree:"),
                                                                  "root": int(input("enter int root:")) if self.data_types1 == "1" else input("Enter string root:"),
                                                                  "counts of childrens for root:": int(input("count for child root:")),
                                                                  }
                                            self.root = General_tree(self.create_G_tree["root"])
                                            self.structure_details = input("which operation do you wanna implement:\1)addchild:\n2)display\n3)remove\n4)is_binary\5)get_height\n6)get_level\n7)search \n8)traverse\n7)back->\n>>>")
                                        while True:
                                            if self.structure_details == "1":
                                                if self.data_types1 =="1":
                                                    if  self.root is None:
                                                        self.get_child=int(input("Enter the count of child for root:"))
                                                        for i in range(self.get_child):
                                                            general_tree.General_tree(int(input("Enter the child for r:")))
                                                        # in here i will add another sub child for each child of this tree in here:
                                                    else:
                                                        print(" this property to add the subchild for this general ptree is \nnot available in here and as soon as possible i will add this property.")
                                                        break
                                                else:
                                                    if  self.root is None:
                                                        self.get_child=int(input("Enter the count of child for root:"))
                                                        for i in range(self.get_child):
                                                            general_tree.General_tree(int(input("Enter the child for r:")))
                                                        # in here i will add another sub child for each child of this tree in here:
                                                    else:
                                                        print(" this property to add the subchild for this general ptree is \nnot available in here and as soon as possible i will add this property.")
                                                        break

                                            elif self.structure_details == "2":
                                                print(root.display())
                                                self.continues = input("for continue.. Y/Q\n>>>")
                                                if self.continues == "y".lower():
                                                    return
                                                break
                                            elif self.structure_details =="3":
                                                print(" this property is not available in here\n and as soon as possible i will add this property")
                                                break
                                            elif self.structure_details =="4":
                                                print(self.root.Is_binary())
                                            elif self.structure_details =="5":
                                                print(self.root.height())
                                            elif self.structure_details =="6":
                                                print(self.root.get_level())
                                            elif self.structure_details == "7":
                                                if self.data_types == "1":
                                                    finder = int(input("which integer value do you wanna find:"))
                                                    print(self.root.search_child(finder))
                                            elif self.structure_details =="8":
                                                pass
                                            else:
                                                print("invalid input please Try again!")
                                                return self.structure_details
                                elif self.get_details == "3":
                                    print("this property is not available in here\n and as soon as possible i will add this property")
                                    return self.get_details
                                elif self.get_details =="4":
                                    return self.tree_option
                        elif self.tree_option == "2":
                            while True:
                                self.get_details = input("which one: 1). definition\n2). structure\n3). others\n4). exit\n>>>")
                                if self.get_details == "1":
                                    while True:
                                        definition = ". A binary search tree is a tree that is structurally a binary tree, and stores data in its nodes very efficiently"
                                        print(definition)
                                        get_more_details = input(" do you wanna more details(y) -> or back(q) ")
                                        if get_more_details == "y".lower():
                                            details_tree = 'A binary search tree (BST) is a special kind of binary tree.\n It is one of the most important and commonly used data structures in computer science\n applications. It provides very fast search, insertion, and deletion operations.'
                                            print(details_tree)
                                        else:
                                            break
                                elif self.get_details == "2":
                                    while True:
                                        if not self.root:
                                            print(" before start the operations you have to create your general tree in here:")
                                            self.data_types = input(
                                                "Enter the data type to Enter:\n 1). int\n2). str\n3). double\n>>>")  # just for Insert the data we need it
                                            if self.data_types == "1":
                                                self.root = BST(int(input("Enter an integer the root for BST:")))
                                            elif self.data_types =="2":
                                                self.root = BST(input("Enter a String the root for BST:"))
                                            else:
                                                self.root = BST(float(input("Enter a Float number for the Root of BST:")))
                                        self.structure_details = input(
                                            "which operation do you wanna implement:\1)Add_Child:\n2)display\n3)remove\n4)utils\5)get_height\n6)get_level\n7)back->\n>>>")
                                        while True:
                                            if self.structure_details == "1":
                                                if self.data_types == "1":
                                                    if not self.root:
                                                        self.get_child = int(input("Enter the count of child for root:"))
                                                        for i in range(self.get_child):
                                                               BST.add_child(self.root,int(input("Enter the child to add:")))
                                                        self.continuee = input("do you wanna continue.. Y/Q")
                                                        if self.continuee == "y".lower():
                                                            return self.get_child
                                                        else:
                                                            break
                                                    else:
                                                        print(" you have been Entered some child in your BST:")
                                                        self.continues = input("do you wanna add some child to your BST")
                                                        if self.continuee == "Y".lower():
                                                            self.get_child = int(
                                                                input("Enter the count of child for root:"))
                                                            for i in range(self.get_child):
                                                                BST.add_child(self.root,
                                                                              int(input("Enter the child to add:")))
                                                            self.continuee = input("do you wanna continue.. Y/Q\n>>>")
                                                            if self.continuee == "y".lower():
                                                                return self.get_child
                                                            else:
                                                                break
                                                        else:
                                                            break
                                                elif self.data_types =="2":
                                                    if not self.root:
                                                        self.get_child = int(input("Enter the count of child for root:"))
                                                        for i in range(self.get_child):
                                                               BST.add_child(self.root,(input("Enter the child to add:")))
                                                        self.continuee = input("do you wanna continue.. Y/Q\n>>>")
                                                        if self.continuee == "y".lower():
                                                            return self.get_child
                                                        else:
                                                            break
                                                    else:
                                                        print(" you have been Entered some child in your BST:")
                                                        self.continues = input("do you wanna add some child to your BST")
                                                        if self.continuee == "Y".lower():
                                                            self.get_child = int(
                                                                input("Enter the count of child for root:"))
                                                            for i in range(self.get_child):
                                                                BST.add_child(self.root,
                                                                              (input("Enter the child to add:")))
                                                            self.continuee = input("do you wanna continue.. Y/Q\n>>>")
                                                            if self.continuee == "y".lower():
                                                                return self.get_child
                                                            else:
                                                                break
                                                        else:
                                                            break

                                                else:
                                                    if not self.root:
                                                        self.get_child = int(input("Enter the count of child for root:"))
                                                        for i in range(self.get_child):
                                                               BST.add_child(self.root,float(input("Enter the child to add:")))
                                                        self.continuee = input("do you wanna continue.. Y/Q\n>>>")
                                                        if self.continuee == "y".lower():
                                                            return self.get_child
                                                        else:
                                                            break
                                                    else:
                                                        print(" you have been Entered some child in your BST:")
                                                        self.continues = input("do you wanna add some child to your BST")
                                                        if self.continuee == "Y".lower():
                                                            self.get_child = int(
                                                                input("Enter the count of child for root:"))
                                                            for i in range(self.get_child):
                                                                BST.add_child(self.root,
                                                                              float(input("Enter the child to add:")))
                                                            self.continuee = input("do you wanna continue.. Y/Q\n>>>")
                                                            if self.continuee == "y".lower():
                                                                return self.get_child
                                                            else:
                                                                break
                                                        else:
                                                            break
                                                        # in here i will add another sub child for each child of this tree in here:
                                            elif self.structure_details == "2":
                                                print(BST.display(self.root))
                                                self.continues = input("for continue.. Y/Q\n>>>")
                                                if self.continues == "y".lower():
                                                    return
                                                break
                                            elif self.structure_details == "3":
                                                print("this property is not available right now so, just wait to implement this property in here:")
                                                break
                                            elif self.structure_details == "4":
                                                    self.details = input("which details do you wanna see:\n1)display leaf\n2)get_path\n3)is_root\n4)is_parent\n>>>")
                                                    if self.details =="1":
                                                        print(BST.leaf_display(self.root))
                                                    elif self.details =="2":
                                                        print(" not available")
                                                        break
                                                    elif self.details =="3":
                                                        self.get_node = input("which node do you wanna find:")
                                                        if self.data_types =="1":
                                                            self.get_node = int(self.get_node)
                                                        elif self.data_types =="2":
                                                            pass
                                                        else:
                                                            self.get_node = float(self.get_node)
                                                        print(BST.is_root(self.root,self.get_node))
                                                    elif self.details =="4":
                                                        print(" this property is not available right now but i will add as soon as possible.")
                                                        break
                                            elif self.structure_details == "5":
                                                break
                                            elif self.structure_details == "6":
                                                break
                                            elif self.structure_details == "7":
                                                break
                                            else:
                                                print("invalid input please Try again!")
                                                return self.structure_details
                                elif self.get_details == "3":
                                    print(
                                        "this property is not available in here\n and as soon as possible i will add this property")
                                    return self.get_details
                                elif self.get_details == "4":
                                    return self.tree_option

                        elif self.tree_option == "3": # AVL-implementation
                            print(" welcome to the AVL implementation:")
                            # adding the code of the python inside the python coding anb other references in here or outer the project to be loaded for hiring the projects :
                            break
                        else:
                            print(" invalid Input!")





























fina_runner = DSA()
fina_runner.ragister()
# fina_runner.login()
